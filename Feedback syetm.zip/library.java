import javax.swing.*;
import java.awt.event.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

class library extends JFrame implements ActionListener
{
    JLabel lb1;
	JTextArea ta;
	JButton b1,b2,b3;

public library()
{
	  setLayout(null);
	  lb1=new JLabel("Description");
	
	  ta=new JTextArea();

	  b1=new JButton("Submit");
	  b2=new JButton("Cancle");
	  b3=new JButton("Home");
	  

	  lb1.setBounds(50,100,100,30);
	  ta.setBounds(150,100,300,110);
	  
	  b1.setBounds(50,400,100,30);
	  b2.setBounds(200,400,100,30);
	  b3.setBounds(350,400,100,30);
	  

	  add(lb1);
      add(ta);  
      add(b1); add(b2); add(b3); 

      b1.addActionListener(this);
      b2.addActionListener(this);
      b3.addActionListener(this);
      
	  setTitle("Library");
	  setVisible(true);
	  setBounds(0,0,1000,1000);

  }
  public void actionPerformed(ActionEvent ae)
{
   
if(ae.getSource()==b1)
			
		{
			try
			{	
				String a="'"+ta.getText()+"'";			

				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
				Statement st=con.createStatement();
		        st.executeUpdate("insert into lfeedback values("+a+")");
				st.close();
				con.close(); 
				JFrame jf=new JFrame();
				JOptionPane.showMessageDialog(jf,"Record Inserted!!");
				new feedback();
				setVisible(false);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		
		}
		if(ae.getSource()==b3)
		{
   	new feedback();
   	setVisible(false);
      }
	}
}
class librarydemo
{
	public static void main(String[] args) 
	{
	   library lb=new library();	
	}
}