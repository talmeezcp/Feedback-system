class employee
{
	int empid;
	String name;
	int salary;
	public void assign()
	{
      empid=501;
      name="Dhoni";
      salary=100000;
	}
	public void disp()
	{
		System.out.println(empid);
		System.out.println(name);
		System.out.println(salary);
	}
}
class demo 
{
	 public static void main(String cp[]) 
	{
		employee e=new employee();
		e.assign();
		e.disp();
	}
	
}