import javax.swing.*;
import java.awt.event.*;
class feedback extends JFrame implements ActionListener
{
	JMenuBar mb;
	JMenu mnu1,mnu2,mnu3;
	JMenuItem mi1,mi2,mi3,mi4,mi5,mi6,mi7,mi8,mi9,mi10,mi11,mi12,mi13,mi14,mi15,mi16;

   public feedback()
{

    mb=new JMenuBar();

    mnu1=new JMenu("Feedback");
    mnu2=new JMenu("Detail");
    mnu3=new JMenu("Report");

    mi1=new JMenuItem("Faculty");
    mi2=new JMenuItem("HOD/Director");
    mi3=new JMenuItem("College");
    mi4=new JMenuItem("Library");
    mi5=new JMenuItem("Faculty Details");
    mi6=new JMenuItem("Subject");
    mi7=new JMenuItem("Less Confidence");
    mi8=new JMenuItem("PoorEnglish");
    mi9=new JMenuItem("Improper pronounication");
    mi10=new JMenuItem("Low voice");
    mi11=new JMenuItem("Less knowledge");
    mi12=new JMenuItem("Improper Board Writing");
    mi13=new JMenuItem("Punctuality");
    mi14=new JMenuItem("Libraian");
    mi15=new JMenuItem("Collegef");
    mi16=new JMenuItem("HOD/Directorf");


    mi1.addActionListener(this);
    mi2.addActionListener(this);
    mi3.addActionListener(this);
    mi4.addActionListener(this);
    mi5.addActionListener(this);
    mi6.addActionListener(this);
    mi7.addActionListener(this);
    mi8.addActionListener(this);
    mi9.addActionListener(this);
    mi10.addActionListener(this);
    mi11.addActionListener(this);
    mi12.addActionListener(this);
    mi13.addActionListener(this);
    mi14.addActionListener(this);
    mi15.addActionListener(this);
    mi16.addActionListener(this);
    


    mnu1.add(mi1); mnu1.add(mi2); mnu1.add(mi3); mnu1.add(mi4);
    mnu2.add(mi5); mnu2.add(mi6); 
    mnu3.add(mi7);mnu3.add(mi8);mnu3.add(mi9);mnu3.add(mi10);mnu3.add(mi11);mnu3.add(mi12);mnu3.add(mi13);mnu3.add(mi14);mnu3.add(mi15);mnu3.add(mi16);
    mb.add(mnu1); mb.add(mnu2); mb.add(mnu3);
    

    setJMenuBar(mb);
    setTitle("Feedback");
    setVisible(true);
    setBounds(0,0,500,500);
  }
  public void actionPerformed(ActionEvent ae)
{
	
     if(ae.getSource()==mi2)
     {
     	new hod();
   	setVisible(false);
    }
  
    if(ae.getSource()==mi5)
    {
      new faculty1();
      setVisible(false);
    }
   
    if(ae.getSource()==mi1)
    {
    	new faculty();
    
  	setVisible(false);
  } 
  
  	if(ae.getSource()==mi3)
  {
    	new college();
  	setVisible(false);
  }
  
  if(ae.getSource()==mi6)
  {
    new subject();
    setVisible(false);
  }
  if(ae.getSource()==mi4)
  {
    new library();
    setVisible(false);
  }
  if(ae.getSource()==mi7)
  {
   new tfeedbackreport();
    setVisible(false);
  }
  if(ae.getSource()==mi14)
  {
    new tfeedbackreport10();
  setVisible(false);
  }
   if(ae.getSource()==mi15)
  {
   new tfeedbackreport8();
    setVisible(false);
  }
  if(ae.getSource()==mi16)
  {
    new tfeedbackreport9();
    setVisible(false);
  }

   if(ae.getSource()==mi8)
  {
    new tfeedbackreport2();
    setVisible(false);
  }
   if(ae.getSource()==mi9)
  {
    new tfeedbackreport3();
    setVisible(false);
  }
   if(ae.getSource()==mi10)
  {
    new tfeedbackreport4();
    setVisible(false);
  }
   if(ae.getSource()==mi11)
  {
    new tfeedbackreport5();
    setVisible(false);
  }
   if(ae.getSource()==mi12)
  {
    new tfeedbackreport6();
    setVisible(false);
  }
   if(ae.getSource()==mi13)
  {
      new tfeedbackreport7();
    setVisible(false);
  }
 }

}
class feed 
  {
  	public static void main(String cp[])
  	{
  		feedback f=new feedback();

  	}
  }
