-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2022 at 12:18 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `cfeedback`
--

CREATE TABLE `cfeedback` (
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cfeedback`
--

INSERT INTO `cfeedback` (`Description`) VALUES
('bekkar clg'),
('mava free campus');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `FacultyID` int(11) NOT NULL,
  `FacultyName` varchar(300) NOT NULL,
  `PanNo.` varchar(300) NOT NULL,
  `AddharNo.` varchar(300) NOT NULL,
  `JoiningDate` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FacultyId` int(11) NOT NULL,
  `FacultyName` varchar(300) NOT NULL,
  `Subject` varchar(300) NOT NULL,
  `Lessconfidence` varchar(300) NOT NULL,
  `PoorEnglish` varchar(300) NOT NULL,
  `Improperpronounication` varchar(300) NOT NULL,
  `Lowvoice` varchar(300) NOT NULL,
  `Lessknowledge` varchar(300) NOT NULL,
  `ImproperBoardWriting` varchar(300) NOT NULL,
  `Punctuality` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FacultyId`, `FacultyName`, `Subject`, `Lessconfidence`, `PoorEnglish`, `Improperpronounication`, `Lowvoice`, `Lessknowledge`, `ImproperBoardWriting`, `Punctuality`) VALUES
(1, 'PROF S.M.JOSHI', 'Business Mathematics', 'Yes', 'No', 'No', 'No', 'Yes', 'Yes', 'Yes'),
(2, 'PROF S.M.JOSHI', 'Algorithm & Program Design', 'No', 'Yes', 'No', 'Yes', 'No', 'Yes', 'No'),
(3, 'PROF S.M.JOSHI', 'Business Mathematics', 'Yes', 'No', 'Yes', 'No', 'Yes', 'No', 'Yes'),
(4, 'PROF S.M.JOSHI', 'Algorithm & Program Design', 'Yes', 'No', 'No', 'No', 'Yes', 'Yes', 'No'),
(5, 'smjoshi', 'Business Mathematics', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes'),
(6, 'smjoshi', 'Business Mathematics', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes', 'Yes'),
(7, 'smjoshi', 'Algorithm & Program Design', 'Yes', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes'),
(8, 'ppmhetre', 'C Programming-I', 'Yes', 'No', 'Yes', 'No', 'Yes', 'No', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `hdfeedback`
--

CREATE TABLE `hdfeedback` (
  `HOD/Director` varchar(200) NOT NULL,
  `Description` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hdfeedback`
--

INSERT INTO `hdfeedback` (`HOD/Director`, `Description`) VALUES
('n.m.damani', 'good'),
('s.w.urale', '');

-- --------------------------------------------------------

--
-- Table structure for table `lfeedback`
--

CREATE TABLE `lfeedback` (
  `Description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lfeedback`
--

INSERT INTO `lfeedback` (`Description`) VALUES
('gadhav aahey'),
('veda aahey');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Username` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`) VALUES
('rahul', 'yash');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `SubjectID` int(11) NOT NULL,
  `SubjectName` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`SubjectID`, `SubjectName`) VALUES
(101, 'Business Mathematics'),
(102, 'Algorithm & Program Design'),
(103, 'C Programming-I'),
(104, 'Business Oranization System'),
(105, 'Fundamentals Of Information Technology'),
(201, 'Computer Organization and Architecture'),
(202, 'DBMS-I'),
(203, 'C Programming-II'),
(204, 'Financial Accounting'),
(205, 'Principal Of Management'),
(301, 'Operating Systems'),
(302, 'Software Engineering'),
(303, 'DBMS-II'),
(304, 'Statistics'),
(305, 'Multimedia Technology'),
(401, 'Computer Networks'),
(402, 'Software Testing'),
(403, 'Java Programming'),
(404, 'Operations Research'),
(405, 'Enterpreneurship Development'),
(501, 'Introduction to the Internet Technologies'),
(502, 'Object Oriented Analysis and Design '),
(503, 'C# Programming '),
(504, 'Graph Theory '),
(601, 'Data Warehousing and Data Mining '),
(602, 'Web Programming '),
(603, 'Software Project Management '),
(604, 'Business Analytics'),
(605, 'AP');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
