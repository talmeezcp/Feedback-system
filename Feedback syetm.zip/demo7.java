import javax.swing.*;
import java.awt.event.*;

class demo7 extends JFrame implements ActionListener
{
	JMenuBar mb;
	JMenu mnu;
	JMenuItem mi1,mi2;
	JLabel lb1,lb2,lb3;
	JTextField tf1,tf2,tf3;
	

	public demo7()
	{
		setLayout(null);
		mb = new JMenuBar();
		mnu = new JMenu("AO");
		mi1 = new JMenuItem("+");
		mi2 = new JMenuItem("-");
		lb1 = new JLabel("Number 1");
		lb2 = new JLabel("Number 2");
		lb3 = new JLabel("Result");
		tf1 = new JTextField();
		tf2 = new JTextField();
		tf3 = new JTextField();
        lb1.setBounds(100,100,100,30);
		lb2.setBounds(100,200,100,30);
		lb3.setBounds(100,300,100,30);
		tf1.setBounds(200,100,100,30);
		tf2.setBounds(200,200,100,30);
		tf3.setBounds(200,300,100,30);
        mb.add(mnu);
		mnu.add(mi1);
		mnu.add(mi2);
		add(lb1);add(lb2);add(lb3);
		add(tf1);add(tf2);add(tf3);
		

		mi1.addActionListener(this);
		mi2.addActionListener(this);

		setJMenuBar(mb);
		setVisible(true);
		setBounds(0,0,500,500);

	}

	public void actionPerformed(ActionEvent ae)
	{
		if (ae.getSource()==mi1)
		{
			int a = Integer.parseInt(tf1.getText());
			int b = Integer.parseInt(tf2.getText());
			int c = a+b;

			tf3.setText(c+"");
		}
		if (ae.getSource()==mi2)
		{
			int a = Integer.parseInt(tf1.getText());
			int b = Integer.parseInt(tf2.getText());
			int c = a-b;

			tf3.setText(c+"");



	}
}
}
class abcdef
{
	public static void main(String cp[])
	{
		demo7 d = new demo7();
		
	}
	}