import javax.swing.*;
class yasu extends JFrame
{
	JLabel ib1,ib2,ib3;
	JTextField tf1,tf2,tf3;
	JButton b1,b2,b3,b4;
	public yasu()
	{
		setLayout(null);
		ib1=new JLabel("Number1");
		ib2=new JLabel("Number2");
		ib3=new JLabel("Number3");
		tf1=new JTextField();
        tf2=new JTextField();
        tf3=new JTextField();
        b1=new JButton("+");
        b2=new JButton("-");
        b3=new JButton("*");
        b4=new JButton("/");
        ib1.setBounds(50,100,100,30);
        ib2.setBounds(50,200,100,30);
        ib3.setBounds(50,300,100,30);
        tf1.setBounds(150,100,100,30);
        tf2.setBounds(150,200,100,30);
        tf3.setBounds(150,300,100,30);
        b1.setBounds(50,400,100,30);
        b2.setBounds(150,400,100,30);
        b3.setBounds(250,400,100,30);
        b4.setBounds(350,400,100,30);
        add(ib1);add(ib2);add(ib3);
        add(tf1);add(tf2);add(tf3);
        add(b1);add(b2);add(b3);add(b4);
        setTitle("Yash");
        setVisible(true);
        setBounds(0,0,500,500);
	}
}
class abcd
{
	public static void main(String cp[]) 
	{
	  yasu y=new yasu();	
	}
}