import java.sql.*;
class rsdemo
{
	public static void main(String cp[]) 
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from stude");
		while (rs.next());
			{
			System.out.print(rs.getInt(1));
			System.out.print(rs.getString(2));
			System.out.print(rs.getInt(3));
		}
			rs.close();
			st.close();
			con.close();
		}
		catch(Exception e){}
	}
}