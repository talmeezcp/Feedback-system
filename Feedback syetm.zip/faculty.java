import javax.swing.*;
import java.awt.event.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
class faculty extends JFrame implements ActionListener
{
    JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9,lb10;
    JTextField tf1;
	JRadioButton r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14;
	
	JComboBox jcb1,jcb2;
	JButton b1,b2,b3;
	
	public faculty()
	{
		setLayout(null);
		lb1=new JLabel("Feedback ID");
		lb2=new JLabel("Faculty Name");
        lb3=new JLabel("Subject");
        lb4=new JLabel("Less confidence");
        lb5=new JLabel("Poor English");
        lb6=new JLabel("Improper pronounication");
        lb7=new JLabel("Low voice");
        lb8=new JLabel("Less knowledge");
        lb9=new JLabel("Improper Board Writing");
        lb10=new JLabel("Punctuality");

        tf1=new JTextField();
    

		r1=new JRadioButton("Yes");
		r2=new JRadioButton("No");
		r3=new JRadioButton("Yes");
		r4=new JRadioButton("No");
		r5=new JRadioButton("Yes");
		r6=new JRadioButton("No");
		r7=new JRadioButton("Yes");
		r8=new JRadioButton("No");
		r9=new JRadioButton("Yes");
		r10=new JRadioButton("No");
		r11=new JRadioButton("Yes");
		r12=new JRadioButton("No");
		r13=new JRadioButton("Yes");
		r14=new JRadioButton("No");
		ButtonGroup bg1=new ButtonGroup();
		ButtonGroup bg2=new ButtonGroup();
		ButtonGroup bg3=new ButtonGroup();
		ButtonGroup bg4=new ButtonGroup();
		ButtonGroup bg5=new ButtonGroup();
		ButtonGroup bg6=new ButtonGroup();
		ButtonGroup bg7=new ButtonGroup();
		bg1.add(r1);
		bg1.add(r2);
		bg2.add(r3);
		bg2.add(r4);
		bg3.add(r5);
		bg3.add(r6);
		bg4.add(r7);
		bg4.add(r8);
		bg5.add(r9);
		bg5.add(r10);
		bg6.add(r11);
		bg6.add(r12);
		bg7.add(r13);
		bg7.add(r14);
		

		b1=new JButton("Insert");
        b2=new JButton("Home");
        b3=new JButton("Show");



        add(lb1);add(lb2);add(lb3);add(lb4);add(lb5);add(lb6);add(lb7);add(lb8);add(lb9);add(lb10);
        add(tf1);
		
        lb1.setBounds(50,100,100,50);        tf1.setBounds(150,100,100,30);  b3.setBounds(250,100,100,30);
        lb2.setBounds(50,150,100,50);
        lb3.setBounds(50,200,200,50);     
        lb4.setBounds(50,250,100,30);
        lb5.setBounds(50,300,100,30);
        lb6.setBounds(50,350,150,30);
        lb7.setBounds(50,400,100,30);
        lb8.setBounds(50,450,100,30);
        lb9.setBounds(50,500,150,30);
        lb10.setBounds(50,550,150,30);


		r1.setBounds(200,250,50,30);
		r2.setBounds(300,250,50,30);
		r3.setBounds(200,300,50,30);
		r4.setBounds(300,300,50,30);
		r5.setBounds(200,350,50,30);
		r6.setBounds(300,350,50,30);
		r7.setBounds(200,400,50,30);
		r8.setBounds(300,400,50,30);
		r9.setBounds(200,450,50,30);
		r10.setBounds(300,450,50,30);
		r11.setBounds(200,500,50,30);
		r12.setBounds(300,500,50,30);
		r13.setBounds(200,550,50,30);
		r14.setBounds(300,550,50,30);

		b1.setBounds(50,600,100,30);	
        b2.setBounds(350,600,100,30);
 

		b1.addActionListener(this);
	    b2.addActionListener(this); 
	    b3.addActionListener(this);
		
		add(r1);add(r2);add(r3);add(r4);add(r5);add(r6);add(r7);add(r8);add(r9);add(r10);add(r11);add(r12);
		add(r13);add(r14);
		add(b1);add(b2);add(b3);
		
		setVisible(true);
		setBounds(0,0,1500,1500);
		setTitle("Faculty Feedback");
		Vector v1=new Vector();
				try
				{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Project","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from faculty");
				
				while(rs.next())
				{
					String s=rs.getString(2);
					v1.add(s);

				}
				
				jcb1=new JComboBox(v1);
				jcb1.setBounds(200,150,150,40);
				add(jcb1);
				rs.close();
				st.close();
				con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}

			Vector v2=new Vector();
				try
				{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Project","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from subject");
				
				while(rs.next())
				{
					String s=rs.getString(2);
					v2.add(s);

				}
				
				jcb2=new JComboBox(v2);
				jcb2.setBounds(200,200,150,40);
				add(jcb2);
				
				rs.close();
				st.close();
				con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				try
				{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Project","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select max(facultyid) from feedback");
				
				rs.next();
				int x=rs.getInt(1)+1;
				tf1.setText(x+"");
				tf1.setEnabled(false);
				rs.close();
				st.close();
				con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}


	}
	
		public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			try
				{
				System.out.println("1");
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("2");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
				System.out.println("3");
				Statement st=con.createStatement();
				String a="'"+jcb1.getItemAt(jcb1.getSelectedIndex())+"'";
				String b="'"+jcb2.getItemAt(jcb2.getSelectedIndex())+"'";
				String c="";
				if(r1.isSelected())
				c="'"+r1.getText()+"'";	
				if(r2.isSelected())
				c="'"+r2.getText()+"'";
				String d="";
				if(r3.isSelected())
				d="'"+r3.getText()+"'";	
				if(r4.isSelected())
				d="'"+r4.getText()+"'";	
				String e="";
				if(r5.isSelected())
				e="'"+r5.getText()+"'";	
				if(r6.isSelected())
				e="'"+r6.getText()+"'";	
				String f="";
				if(r7.isSelected())
				f="'"+r7.getText()+"'";	
				if(r8.isSelected())
				f="'"+r8.getText()+"'";	
				String g="";
				if(r9.isSelected())
				g="'"+r9.getText()+"'";	
				if(r10.isSelected())
				g="'"+r10.getText()+"'";	
				String h="";
				if(r11.isSelected())
				h="'"+r11.getText()+"'";	
				if(r12.isSelected())
				h="'"+r12.getText()+"'";
				String i="";	
			    if(r13.isSelected())
				i="'"+r13.getText()+"'";	
			    if(r14.isSelected())
				i="'"+r14.getText()+"'";
				int j=Integer.parseInt(tf1.getText());	
				String query="insert into feedback values("+j+","+a+","+b+","+c+","+d+","+e+","+f+","+g+","+h+","+i+")";	//System.out.println(a+b+c+d+e+f+g+h+i);
				st.executeUpdate(query);
				System.out.println(query);
				st.close();
				con.close();
				JFrame xf=new JFrame();
				JOptionPane.showMessageDialog(xf,"Saved Successfully");
				new feedback();
				setVisible(false);
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				
	}	


	 if(ae.getSource()==b2)
	 {
     	new feedback();
   	    setVisible(false);
		
	  }
	  

	}
  }

class facultydemo
{
	public static void main(String cp[])
	{
		faculty f=new faculty();
	}
}