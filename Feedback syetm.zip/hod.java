import javax.swing.*;
import java.awt.event.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

class hod extends JFrame implements ActionListener
{
    JLabel lb1,lb2;
	JTextField tf1;
	JTextArea ta;
	JButton b1,b2;

public hod()
{
	  setLayout(null);
	  lb1=new JLabel("HOD/Director");
	  lb2=new JLabel("Description");

	  tf1=new JTextField();
	  ta=new JTextArea();

	  b1=new JButton("Submit");
	  b2=new JButton("Home");

	  lb1.setBounds(50,100,100,30);
	  lb2.setBounds(50,200,100,30);

	  tf1.setBounds(150,100,100,30);
	  ta.setBounds(150,200,300,110);
	  
	  b1.setBounds(50,400,100,30);
	  b2.setBounds(150,400,100,30);

      
      b1.addActionListener(this);
      b2.addActionListener(this);

	  add(lb1); add(lb2);
      add(tf1); add(ta);  
      add(b1);  add(b2);

	  setTitle("HOD/Director");
	  setVisible(true);
	  setBounds(0,0,500,500);

  }
  public void actionPerformed(ActionEvent ae)
  {
  	if(ae.getSource()==b1)
	{
       try
			{
				String a="'"+tf1.getText()+"'";		
				String b="'"+ta.getText()+"'";		

				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
				Statement st=con.createStatement();
				st.executeUpdate("insert into hdfeedback values("+a+","+b+")");
				st.close();
				con.close();

				JFrame jf=new JFrame();
				JOptionPane.showMessageDialog(jf,"Record Inserted!!");
				new feedback();
				setVisible(false);
			}
			catch(Exception e)
			{
				System.out.println(e);
			}

    }
    if(ae.getSource()==b2)
    {
     
     	new feedback();
   	setVisible(false);
    }
}
}
class hoddemo
{
	public static void main(String[] args) 
	{
	   hod h=new hod();	
	}
}