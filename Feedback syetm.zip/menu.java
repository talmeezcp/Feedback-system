import javax.swing.*;
class menu1 extends JFrame
{
	JMenuBar mb;
	JMenu mnu1,mnu2;
	JMenuItem mi1,mi2,mi3,mi4;
	public menu1()
	{
		mb= new JMenuBar();
		mnu1= new JMenu("File");
		mnu2= new JMenu("Edit");
		mi1= new JMenuItem("New");
		mi2= new JMenuItem("Open");
		mi3= new JMenuItem("Copy");
		mi4= new JMenuItem("Paste");
		mb.add(mnu1);
		mb.add(mnu2);
		mnu1.add(mi1);
		mnu1.add(mi2);
		mnu2.add(mi3);
		mnu2.add(mi4);
		setJMenuBar(mb);
		setVisible(true);
		setBounds(0,0,600,600);

	}
}
class an
{
	public static void main(String[] args) 
	{
		menu1 m= new menu1();
	}
}