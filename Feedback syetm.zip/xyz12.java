import java.awt.*;
import java.awt.event.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class xyz12 extends JFrame implements ActionListener
{
	JLabel l1,l2,l3,l4,l5,l6,l7;
	JTextField t1,t2,t3,t4,t5,t6;
	JButton b1,b2,b3,b4,b5,b6,b7,b8,b9;
	JComboBox c1,c2;
	String value;
	
	public xyz12()
	{
		setLayout(null);
		l1=new JLabel("Employee ID");
		l2=new JLabel(" Employee Name");
		l3=new JLabel("Total Days");
		l4=new JLabel("Wages/Salary Per Day");
		l5=new JLabel("Month");
		l6=new JLabel("Year");
		l7=new JLabel("Total Wages/Salary");
		b1=new JButton("Show");
		b2=new JButton("Compute");
		b3=new JButton("Insert");
        b4=new JButton("Update");
        b5=new JButton("Delete");
        b6=new JButton("Cancel");
        b7=new JButton("Home");b8=new JButton("Set");b9=new JButton("Clear");
        t1=new JTextField();
        t2=new JTextField();
        t3=new JTextField();
        t4=new JTextField();
        t5=new JTextField();
        t6=new JTextField();
        c1=new JComboBox();
        c1.addItem("---Select---");c1.addItem("January");c1.addItem("February");c1.addItem("March");c1.addItem("April");
        c1.addItem("May");c1.addItem("June");c1.addItem("July");c1.addItem("August");
        c1.addItem("September");c1.addItem("October");c1.addItem("November");c1.addItem("December");
        l1.setBounds(50,100,200,30);t1.setBounds(150,100,200,30);b8.setBounds(350,100,100,30);b1.setBounds(450,100,100,30);
        l2.setBounds(50,200,100,30);t2.setBounds(150,200,200,30);
        l3.setBounds(170,300,100,30);t3.setBounds(250,300,200,30);
        l4.setBounds(120,400,200,30);t4.setBounds(260,400,200,30);
        l5.setBounds(170,500,100,30);c1.setBounds(220,500,200,30);l6.setBounds(500,500,100,30);t5.setBounds(550,500,200,30);
        l7.setBounds(150,600,200,30);t6.setBounds(270,600,200,30);b2.setBounds(460,600,100,30);
        b3.setBounds(50,700,100,30);b4.setBounds(150,700,100,30);b5.setBounds(250,700,100,30);
        b6.setBounds(350,700,100,30);b7.setBounds(550,700,100,30);b9.setBounds(450,700,100,30);
        add(l1);add(l2);add(l3);add(l4);add(l5);add(l6);add(l7);
        add(c1);add(b9);
        add(t1);add(t2);add(t3);add(t4);add(t5); add(t6);
        add(b1);add(b2);add(b3);add(b4);add(b5);add(b6);add(b7);add(b8);
        t5.setText("2021");
        t5.setEditable(false);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        b8.addActionListener(this);
         b9.addActionListener(this);
        c1.addActionListener(this);
       setVisible(true);
       setTitle("Vidhi Automobile");
       setBounds(0,0,1500,1500);
      Vector c1=new Vector();
				try
				{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from subject");
				
				while(rs.next())
				{
					String s=rs.getString(2);
					v1.add(s);

				}
				
				c1=new JComboBox(v1);
				c1.setBounds(200,150,100,30);
				add(c1);
				rs.close();
				st.close();
				con.close();
				}catch(Exception e)
				{System.out.println(e);}

			
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b8)
		{
			//int x=Integer.parseInt(t1.getText());
			//int flag=0;
			//String z;
			//System.out.println(x);
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select  eid,name from emp");
			rs.next();
                t1.setText(rs.getInt(1)+"");
				t2.setText(rs.getString(2));
				st.close();
			   con.close();
			   rs.close();
			}
			catch(Exception e)
			{

			}
		}
		if(ae.getSource()==b2)
		{
			int z=Integer.parseInt(t3.getText());
			int a=Integer.parseInt(t4.getText());
			value=c1.getSelectedItem().toString();
			int b=z*a;
			t6.setText(b+"");
		}
		if(ae.getSource()==b3)
		{
			int x=Integer.parseInt(t1.getText());
			String y="'"+t2.getText()+"'";
			int z=Integer.parseInt(t3.getText());
			int a=Integer.parseInt(t4.getText());
			String value1;
			value1="'"+value+"'";
			int b=2021;
			int c=Integer.parseInt(t6.getText());
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
				Statement st=con.createStatement();
				st.executeUpdate("insert into empsal values("+x+","+y+","+z+","+a+","+value1+","+b+","+c+")");
				JFrame f=new JFrame();
			   JOptionPane.showMessageDialog(f,"Record Inserted Successfully");
			   t3.setText("");t4.setText("");t5.setText("");t6.setText("");t1.setText("");t2.setText("");
			   //c1.setSelectedIndex(0);
				con.close();
				st.close();
			}
			catch(Exception e)
			{

			}
		}
		if(ae.getSource()==b1)
		{
			int x=Integer.parseInt(t1.getText());
			try
			{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from empsal where eid="+x+"");
			while(rs.next())
			{
			t2.setText(rs.getString(2));
			t1.setEditable(false);t2.setEditable(false);
			t3.setText(rs.getInt(3)+"");
			t4.setText(rs.getInt(4)+"");
			//String month=rs.getString(5);
			//System.out.println(month);	
			//System.out.println("1");
			//c2=new JComboBox(month);c2.setBounds(220,500,200,30);add(c2);
			//c1.addItem(rs.getString(5));
			//System.out.println("2");
			String name=rs.getString(5);
			c1.addItem(name);
			//c1.setSelectdItem("");

//System.out.println(name);
			//c1.add("name");
			//c1.addItem(rs.getString(5));
			/*String name;
			name=rs.getString(5);
			System.out.println(name);
			//value=name;
			//System.out.println(value);
			//add(c1);
			c1.addItem(name);*/
			t5.setText(rs.getInt(6)+"");
			t6.setText(rs.getInt(7)+"");
		}
			}
			catch(Exception e)
			{
				JFrame f=new JFrame();
				JOptionPane.showMessageDialog(f," Record not found");
				t3.setText("");t4.setText("");t5.setText("");t6.setText("");t1.setText("");t2.setText("");
			  // c1.setSelectedIndex(0);
			}

		}
		if(ae.getSource()==b4)
		{
			
			int x=Integer.parseInt(t1.getText());
			int z=Integer.parseInt(t3.getText());
			int a=Integer.parseInt(t4.getText());
			value=c1.getSelectedItem().toString();
			String value1;
			value1="'"+value+"'";
			int b=Integer.parseInt(t6.getText());
			 try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
				Statement st=con.createStatement();		
				int i=st.executeUpdate("update empsal set days="+z+",w_s="+a+",month="+value1+",total="+b+" where eid="+x+"");
				JFrame f2=new JFrame();
				if(i>0)
				{
				JOptionPane.showMessageDialog(f2,"Updated Record Successfully");
				 t3.setText("");t4.setText("");t5.setText("");t6.setText("");t1.setText("");t2.setText("");
			   c1.setSelectedIndex(0);
					}
				st.close();
				con.close();
				
			}
			catch(Exception e1)
			{
			}
		}
		if(ae.getSource()==b5)
		{
				int x=Integer.parseInt(t1.getText());
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root",""); 
				Statement st=con.createStatement();
				int i=st.executeUpdate("delete from empsal where eid="+x+"");
				JFrame f=new JFrame();
				if(i>0)
				{
				JOptionPane.showMessageDialog(f,"Deleted Record Successfully");
				t3.setText("");t4.setText("");t5.setText("");t6.setText("");t1.setText("");t2.setText("");
			  // c1.setSelectedIndex(0);		
			    }
			   else
			   {
				JOptionPane.showMessageDialog(f," Record not found ");
				t3.setText("");t4.setText("");t5.setText("");t6.setText("");t1.setText("");t2.setText("");
			   //c1.setSelectedIndex(0);				
			     }

				st.close();
				con.close();
			}
			catch(Exception e)
			{

			}

		}
		if(ae.getSource()==b6)
		{
			System.exit(0);
		}
		
		if(ae.getSource()==b9)
		{
			t3.setText("");t4.setText("");t5.setText("");t6.setText("");t1.setText("");t2.setText("");
			   c1.setSelectedIndex(0);	

		}
	}
}
class pqr
{
	public static void main(String[] args) 
	{
		xyz12 x=new xyz12();
		
	}
}