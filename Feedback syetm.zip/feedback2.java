import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
class feedback2 extends JFrame implements ActionListener
{
	JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9;
	JRadioButton r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12;
	JTextField tf1;
	JComboBox jcb1,jcb2;
	ButtonGroup bg1,bg2,bg3,bg4,bg5,bg6;

	JButton b1,b2,b3;	
	public feedback2()
	{
		setLayout(null);
		lb1=new JLabel("Feedback Number");
		lb2=new JLabel("Faculty Name");
		lb3=new JLabel("Subject Name");
		lb4=new JLabel("Poor English");
		lb5=new JLabel("Low Voice");
		lb6=new JLabel("Poor Knowledge");
		lb7=new JLabel("Fast Speaking");
		lb8=new JLabel("Poor Classcontrol");
		lb9=new JLabel("Improper Boardwriting");
		tf1=new JTextField();
		r1=new JRadioButton("Yes");
		r2=new JRadioButton("No");
		r3=new JRadioButton("Yes");
		r4=new JRadioButton("No");
		r5=new JRadioButton("Yes");
		r6=new JRadioButton("No");
		r7=new JRadioButton("Yes");
		r8=new JRadioButton("No");
		r9=new JRadioButton("Yes");
		r10=new JRadioButton("No");
		r11=new JRadioButton("Yes");
		r12=new JRadioButton("No");
		b1=new JButton("Save");
		b2=new JButton("Home Page");
		b3=new JButton("Exit");
		bg1=new ButtonGroup();
		bg2=new ButtonGroup();
		bg3=new ButtonGroup();
		bg4=new ButtonGroup();
		bg5=new ButtonGroup();
		bg6=new ButtonGroup();
		bg1.add(r1);bg1.add(r2);
		bg2.add(r3);bg2.add(r4);
		bg3.add(r5);bg3.add(r6);
		bg4.add(r7);bg4.add(r8);
		bg5.add(r9);bg5.add(r10);
		bg6.add(r11);bg6.add(r12);
		add(lb1);add(lb2);add(lb3);add(lb4);add(lb5);add(lb6);add(lb7);add(lb8);add(lb9);
		add(tf1);add(b1);add(b2);add(b3);
		add(r1);add(r2);add(r3);add(r4);add(r5);add(r6);add(r7);add(r8);add(r9);add(r10);add(r11);add(r12);	
		lb1.setBounds(50,100,150,30);tf1.setBounds(200,100,100,30);
		lb2.setBounds(50,150,100,30);
		lb3.setBounds(50,200,100,30);
		lb4.setBounds(50,250,150,30);r1.setBounds(200,250,100,30);r2.setBounds(300,250,100,30);
		lb5.setBounds(50,300,150,30);r3.setBounds(200,300,100,30);r4.setBounds(300,300,100,30);
		lb6.setBounds(50,350,150,30);r5.setBounds(200,350,100,30);r6.setBounds(300,350,100,30);
		lb7.setBounds(50,400,150,30);r7.setBounds(200,400,100,30);r8.setBounds(300,400,100,30);
		lb8.setBounds(50,450,150,30);r9.setBounds(200,450,100,30);r10.setBounds(300,450,100,30);
		lb9.setBounds(50,500,150,30);r11.setBounds(200,500,100,30);r12.setBounds(300,500,100,30);
		b1.setBounds(50,550,150,30);b2.setBounds(200,550,100,30);b3.setBounds(300,550,100,30);
		b1.addActionListener(this);b2.addActionListener(this);	b3.addActionListener(this);
		setVisible(true);
		setBounds(400,400,400,400);
		setTitle("Feedback Details");
Vector v1=new Vector();
				try
				{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from subject");
				
				while(rs.next())
				{
					String s=rs.getString(2);
					v1.add(s);

				}
				
				jcb1=new JComboBox(v1);
				jcb1.setBounds(200,150,100,30);
				add(jcb1);
				rs.close();
				st.close();
				con.close();
				}catch(Exception e)
				{System.out.println(e);}

			Vector v2=new Vector();
				try
				{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from subject");
				
				while(rs.next())
				{
					String s=rs.getString(2);
					v2.add(s);

				}
				
				jcb2=new JComboBox(v2);
				jcb2.setBounds(200,200,100,30);
				add(jcb2);
				
				rs.close();
				st.close();
				con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}


	}
	public void actionPerformed(ActionEvent ae)
	 
	{
     if(ae.getSource()==b3)
     	new hod();
   	setVisible(false);
  }
}

class ddemo
{
	public static void main(String cp[])
	{
		new feedback2();
	}
}