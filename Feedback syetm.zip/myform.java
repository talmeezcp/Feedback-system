import javax.swing.*;
 class myform extends JFrame
 {
 	public myform()

 	{
 		setTitle("Yash");
 		setVisible(true);
 		setBounds(0,0,400,400);

 	}
 }

 	class abcd
 	{
 		public static void main(String cp[])  			
 		

 		{
 			myform f=new myform();

 		}
 	}
  