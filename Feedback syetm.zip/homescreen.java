import javax.swing.*;
import java.awt.event.*;
class homescreen extends JFrame implements ActionListener

{
	JMenuBar mb;
	JMenu mnu1,mnu2;
	JMenuItem mi1,mi2,mi3;

   public homescreen()
{

    mb=new JMenuBar();
    mnu1=new JMenu("Maintenance");
    mnu2=new JMenu("Employee");
    mi1=new JMenuItem("Maintenance");
    mi2=new JMenuItem("Employee Detail");
    mi3=new JMenuItem("Salary");

    mi1.addActionListener(this);
    mi2.addActionListener(this);
    mi3.addActionListener(this);

    mnu1.add(mi1); mnu2.add(mi2); mnu2.add(mi3);
    mb.add(mnu1); mb.add(mnu2);
    
    setJMenuBar(mb);
    setTitle("Homepage");
    setVisible(true);
    setBounds(0,0,500,500);

}

public void actionPerformed(ActionEvent ae)
{
  if(ae.getSource()==mi1)

{
  JLabel lb1,lb2,lb3,lb4,lb5,lb6;
    JTextField tf1,tf2,tf3,tf4;
    JTextArea  ta1;
    JButton b1,b2,b3,b4;
    {
    setLayout (null);
        lb1=new JLabel("Maintenance Number");
        lb2=new JLabel("Date");
        lb3=new JLabel("(DD-MM-YYYY)");
        lb4=new JLabel("Description");
        lb5=new JLabel("Person Responsible");
        lb6=new JLabel("Amount");

        tf1=new JTextField();
        tf2=new JTextField();
        tf3=new JTextField();
        tf4=new JTextField();
        ta1=new JTextArea();
        
        b1=new JButton("Insert");
        b2=new JButton("Update");
        b3=new JButton("Delete");
        b4=new JButton("Home");

        lb1.setBounds(50,100,150,30);
        lb2.setBounds(50,200,100,30);
        lb3.setBounds(310,200,100,30);
        lb4.setBounds(50,300,100,30);
        lb5.setBounds(50,450,200,30);
        lb6.setBounds(50,550,100,30);

        tf1.setBounds(200,100,100,30);
        tf2.setBounds(200,200,100,30);
        tf3.setBounds(200,450,100,30);
        tf4.setBounds(200,550,100,30);

        ta1.setBounds(200,300,300,110);

        b1.setBounds(50,650,100,30);
        b2.setBounds(150,650,100,30);
        b3.setBounds(250,650,100,30);
        b4.setBounds(400,650,100,30);

       add(lb1);add(lb2);add(lb3);
       add(lb4);add(lb5);add(lb6);
       add(tf1);add(tf2);add(tf3);
       add(tf4);add(ta1);
      add (b1);add (b2);add (b3);
    add (b4);

    b1.addActionListener(this);
    b2.addActionListener(this);
    b3.addActionListener(this);
    b4.addActionListener(this);
    
    setTitle("Maintenance");
    setVisible(true);
    setBounds(0,0,1000,1000);
  }
}
}
}

  class xyz 
  {
  	public static void main(String cp[])
  	{
  		homescreen h=new homescreen();

  	}
  }



  




