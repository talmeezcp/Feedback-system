class Yash 
{
	public static void main (String[]args) 
	{
		System.out.println("WELCOME TO MY WORLD");
	}
}