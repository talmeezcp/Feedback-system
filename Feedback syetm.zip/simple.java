class student
{
	int rollno;
	String name;
	public void assign()
	{
	rollno=101;
	name="yash";
    }
	public void disp()
	{
      System.out.println(rollno);
      System.out.println(name);
	}
}
class demo
{
	public static void main(String cp[])
	{
	   student s=new student();
	   s.assign();
	   s.disp();
	}
}