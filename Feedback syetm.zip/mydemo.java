import javax.swing.*;
class mydemo extends JFrame

{
	JLabel ib1,ib2;
	JTextField tf1,tf2;
	JButton b1,b2;
	public mydemo()
	{
		setLayout(null);
		ib1=new JLabel("TechName");
		ib2=new JLabel("workim");
		tf1=new JTextField();
		tf2=new JTextField();
		b1=new JButton("save");
		b2=new JButton("cancel");
		ib1.setBounds(50,100,100,30);
		ib2.setBounds(150,100,100,30);
		tf1.setBounds(50,200,100,30);
		tf2.setBounds(150,200,100,30);
		b1.setBounds(50,300,100,30);
		b2.setBounds(150,300,100,30);
		add(ib1);add(ib2);
		add(tf1);add(tf2);
		add(b1);add(b2);
		setVisible(true);
		setBounds(0,0,400,400);
	}
}
class abc0
{
	public static void main(String cp[]) 
	{
		mydemo d=new mydemo();


	}
}