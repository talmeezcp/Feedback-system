import javax.swing.*;
import java.awt.event.*;
class vaisha extends JFrame implements ActionListener
{
	JTextField tf1,tf2;
	JButton b1;
	public vaisha()
	{
		setLayout(null);
		tf1=new JTextField();
		tf2=new JTextField();
        b1=new JButton("Transferme");
        tf1.setBounds(50,100,100,30);
        tf2.setBounds(50,200,100,30);
        b1.setBounds(50,300,100,30);
        add(tf1);add(tf2);
        add(b1);
        b1.addActionListener(this);
        setVisible(true);
        setBounds(0,0,500,500);
	}
     public void actionPerformed(ActionEvent ae)
     {
     if(ae.getSource()==b1)
     {
       String a=tf1.getText();
       tf2.setText(a);

     }
    }
}
    class sv
    {
      public static void main(String cp[] )
       {
      	vaisha v=new vaisha();
      }
    }
 