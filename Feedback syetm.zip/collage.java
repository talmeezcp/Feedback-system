import javax.swing.*;
import java.awt.event.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

class college extends JFrame  implements ActionListener
{
    JLabel lb1,lb2;
    JTextField tf1;
	JTextArea ta;
	JButton b1,b2,b3,b4,b5;

public college()
{
	  setLayout(null);
	  lb1=new JLabel("Feedback ID");
	  lb2=new JLabel("Description");

	  tf1=new JTextField();
	  ta=new JTextArea();

	  b1=new JButton("Submit");
	  b2=new JButton("Cancle");
	  b3=new JButton("Clear");
	  b4=new JButton("Home");
	  b5=new JButton("Show");

	  lb1.setBounds(50,100,100,30); tf1.setBounds(150,100,100,30); b5.setBounds(250,100,80,30);
	  lb2.setBounds(50,200,100,30);
	  ta.setBounds(150,200,300,110);
	  
	  b1.setBounds(50,400,100,30);
	  b2.setBounds(150,400,100,30);
	  b3.setBounds(250,400,100,30);
	  b4.setBounds(350,400,100,30);

	  b1.addActionListener(this);
	  b2.addActionListener(this);
	  b3.addActionListener(this);
	  b4.addActionListener(this);
	  b5.addActionListener(this);

	  add(lb1);add(lb2);
      add(ta);add(tf1);
      add(b1); add(b2); add(b3); add(b4);add(b5);

	  setTitle("College");
	  setVisible(true);
	  setBounds(0,0,1000,1000);
	  try
				{
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Project","root","");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select max(Description) from cfeedback");
				
				rs.next();
				int x=rs.getInt(1)+1;
				tf1.setText(x+"");
				tf1.setEnabled(false);
				rs.close();
				st.close();
				con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}


  }
  public void actionPerformed(ActionEvent ae)
  {
  	if(ae.getSource()==b1)
			
		{
			try
			{	
				String a="'"+ta.getText()+"'";			

				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
				Statement st=con.createStatement();
		        st.executeUpdate("insert into cfeedback values("+a+")");
				st.close();
				con.close(); 
				JFrame jf=new JFrame();
				JOptionPane.showMessageDialog(jf,"Record Inserted!!");
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		
  }
}
class collegedemo
{
	public static void main(String[] args) 
	{
	   college c=new college();	
	}
}