import java.sql.*;
class  inserdemo
{
   public static void main(String cp[]) 
   {
   	try
   	{
   	Class.forName("com.mysql.jdbc.Driver");
   	Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","");
   	Statement st= con.createStatement();
   	st.executeUpdate("insert into stude values(1,'suyash',2000)");
  	st.close();
   	con.close();

   }
     catch(Exception e)
     {
       System.out.println(e);
     }
   }
}