import javax.swing.*;
class dth extends JFrame 
{
	JLabel ib1,ib2,ib3,ib4,ib5;
	JTextField tf1,tf2,tf3,tf4,tf5;
	JButton b1,b2,b3,b4;
	public dth()
	{
		setLayout(null);
		ib1=new JLabel("Date");
		ib2=new JLabel("Tech Name");
        ib3=new JLabel("Cust.ID");
		ib4=new JLabel("work");
        ib5=new JLabel("Charges");
		tf1=new JTextField();
        tf2=new JTextField();
        tf3=new JTextField();
        tf3=new JTextField();
        tf4=new JTextField();
        tf5=new JTextField();
        b1=new JButton("Save");
        b2=new JButton("Cancel");
        b3=new JButton("Reset");
        b4=new JButton("Update");
        ib1.setBounds(50,100,100,30);
        ib2.setBounds(50,200,100,30);
        ib3.setBounds(50,300,100,30);
        ib4.setBounds(50,400,100,30);
        ib5.setBounds(50,500,100,30);
        tf1.setBounds(100,100,100,30);
        tf2.setBounds(100,200,100,30);
        tf3.setBounds(100,300,100,30);
        tf4.setBounds(100,400,100,30);
        tf5.setBounds(100,500,100,30);
        b1.setBounds(50,600,50,30);
        b2.setBounds(100,600,50,30);
        b3.setBounds(200,600,50,30);
        b4.setBounds(300,600,50,30);
        add(ib1);add(ib2);add(ib3);add(ib4);add(ib5);
        add(tf1);add(tf2);add(tf3);add(tf4);add(tf5);
        add(b1);add(b2);add(b3);add(b4);
        
        setTitle("Bright Earth Solar Technology");
        setVisible(true);
        setBounds(0,0,1000,1000);
	}
}
    
class bright 
 {
   public static void main(String cp[]) 
    {
     dth d= new dth();
    }
 }
