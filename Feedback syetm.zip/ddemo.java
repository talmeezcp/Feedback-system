class ddemo
{
	public ddemo()
	{

	System.out.println("Constructor");
	}
	public void disp()
	{
		System.out.println("In Disp");
	}
}
class dd
{
	public static void main(String cp[]) 
	{
		demo d=new demo();
		d.disp();
	}
}