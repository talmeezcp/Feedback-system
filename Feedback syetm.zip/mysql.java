import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
class mysql extends JFrame implements ActionListener
{
	JLabel lb1,lb2,lb3;
	JTextField tf1,tf2,tf3;
	JButton b1;
	public mysql()
	{
       setLayout(null);
       lb1=new JLabel("RollNo");
       lb2=new JLabel("Name");
       lb3=new JLabel("fees");
       tf1=new JTextField();
       tf2=new JTextField();
       tf3=new JTextField();
       b1=new JButton("Login");
       lb1.setBounds(50,100,100,30);
       lb2.setBounds(50,200,100,30);
       lb2.setBounds(50,300,100,30);
       tf1.setBounds(150,100,100,30);
       tf2.setBounds(150,200,100,30);
       tf3.setBounds(150,300,100,30);
       b1.setBounds(50,300,100,30);
       add(lb1);add(lb2);add(ib3);
       add(tf1);add(tf2);add(tf3);
       add(b1);
       b1.addActionListener(this);
       setTitle("Yash");
       setVisible(true);
       setBounds(0,0,500,500);
  } 
public void actionPerformed(ActionEvent ae)
{
  if(ae.getSource()==b1)
  {
     int a=Integer.parseInt(tf1.getText());
     String b="'"  +  tf2.getText() +"'";
     int c=Integer.parseInt(tf3.getText());
  try
  {
      Class.forName("com.mysql.jdbc.Driver");
    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","");
    Statement st= con.createStatement();
    st.executeUpdate("insert into stude values("+a+","+b+","+c+")");
    st.close();
    con.close();
  }
  catch(Exception e)
  {

  }
 }
}
}

class ya
{
  public static void main(String cp[])
  {
   mysql m=new mysql();
  }
}


