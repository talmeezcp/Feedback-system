import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class atrribute extends JFrame implements ActionListener
{
	JLabel lb1,lb2;
	JTextField tf1,tf2;
	JButton b1,b2,b3;
		public atrribute()
		{
			setLayout(null);
			lb1=new JLabel("Subject id");
			lb2=new JLabel("Subject Name");
			tf1=new JTextField();
			tf2=new JTextField();
			b1=new JButton("Insert");
			b2=new JButton("HomePage");
			b3=new JButton("Cancel");

			lb1.setBounds(50,100,100,30);
			lb2.setBounds(50,150,100,30);
			tf1.setBounds(150,100,100,30);
			tf2.setBounds(150,150,100,30);
			b1.setBounds(50,300,100,30);
			b2.setBounds(150,300,100,30);
			b3.setBounds(250,300,100,30);

			b1.addActionListener(this);
			b2.addActionListener(this);
			b3.addActionListener(this);
			add(lb1);add(lb2);
			add(tf1);add(tf2);
			add(b1);add(b2);add(b3);
			setTitle("Atrributes insert");
			setVisible(true);
			setBounds(0,0,500,500);
                                       }

		public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			{

				try
				{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				
				Connection con=DriverManager.getConnection("jdbc:odbc:dsn_feedback");
				
				Statement st=con.createStatement();
				int atrributeid=Integer.parseInt(tf1.getText());
				String atrributename="'"+tf2.getText()+"'";
		String query="insert into subject values("+atrributeid+","+atrributename+")";	
  st.executeUpdate(query);
System.out.println(query);
		JFrame f1=new JFrame();
		JOptionPane.showMessageDialog(f1,"Insert Successful!!!");
		
				st.close();
				con.close();
			}catch(Exception e){System.out.println(e);}
		

          }
			if(ae.getSource()==b2)
			{
				new menudemo();
				setVisible(false);

			}

			if(ae.getSource()==b3)
			{
				System.exit(0);
			}
	
		}

}

	class insert
{
	public static void main(String cp[])
	{
		new atrribute(); 
	}
}



	
		
	